package org.usfirst.frc.team5496.robot.subsystems;

import org.usfirst.frc.team5496.robot.OI;
import org.usfirst.frc.team5496.robot.Robot;
public class BasicAuto  {
	public static final drive Drive = new drive();
	public static OI oi;
	
	public static void auto() {
		// TODO Auto-generated method stub
	       Drive.backward();
	        if(Robot.oi.hi<4);
	        {
	           Robot.oi.hi++;
	        Drive.left();
	        }
	        if(Robot.oi.hi>4)   
	        {
	        Drive.shoot();  
	        }	
	}

}
