package org.usfirst.frc.team5496.robot.subsystems;

import org.usfirst.frc.team5496.robot.OI;
import org.usfirst.frc.team5496.robot.Robot;

public class ArmAuto {
	public static final drive Drive = new drive();
	public static OI oi;
	
	public static void auto() {
		// TODO Auto-generated method stub
	       Drive.backward();
	        if(Robot.oi.hi<4);
	        {
	           Robot.oi.hi++;
	        Drive.left();
	        } 
	        Drive.lift();
	        Drive.forward();
	        if(Robot.oi.hi<6);
	        {
	           Robot.oi.hi++;
	        Drive.right();
	        } 
	        if(Robot.oi.hi>6)   
	        {
	        Drive.shoot();  
	        }	
	       
 }
}