package org.usfirst.frc.team5496.robot.commands;
import org.usfirst.frc.team5496.robot.Robot;
import edu.wpi.first.wpilibj.command.Command;
/**
 * 
 *
 */
public class movement extends Command {

    public movement() {
        // Use requires() here to declare subsystem dependencies
        // eg. requires(chassis);
    }
    // Called just before this Command runs the first time
    protected void initialize() {

    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	if(Robot.buttonz.value> 0.3 && Robot.buttonz.value2> 0.3)
        {
        	Robot.Drive.forward();
        }
        	if(Robot.buttonz.value< -0.3 && Robot.buttonz.value2< -0.3)
            {
            	Robot.Drive.backward();
        }
        	if(Robot.buttonz.value> 0.3 && Robot.buttonz.value2< -0.3)
            {
            	Robot.Drive.left();
            }
        	if(Robot.buttonz.value< -0.3 && Robot.buttonz.value2> 0.3)
            {
            	Robot.Drive.right();
            }
        	if(Robot.buttonz.number>.03)
        	{
        	Robot.Drive.shoot();
        	}
        	if(Robot.buttonz.liftV==true)
        	{
        		Robot.Drive.lift();
        	}
        
        	if(Robot.buttonz.extra==true)
        	{
        	Robot.Up.liftShoot();
        	}
        }


    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return false;
    }

    // Called once after isFinished returns true
    protected void end() {
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    	System.out.print("movement inturupted");
    }
}
