package org.usfirst.frc.team5496.robot.triggers;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Joystick.RumbleType;

public class buttony {
	public static Joystick joysticks = new Joystick(0);
	public double value=joysticks.getRawAxis(1);
	public double number=joysticks.getRawAxis(5);
	public double value2=joysticks.getRawAxis(3);
	public boolean boom=joysticks.getRawButton(6);
	public boolean liftV=joysticks.getRawButton(5);
	public boolean extra=joysticks.getRawButton(1);
	public static int joy = joysticks.getPOV(1);
}