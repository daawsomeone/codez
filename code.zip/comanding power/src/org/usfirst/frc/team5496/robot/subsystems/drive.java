
package org.usfirst.frc.team5496.robot.subsystems;

import edu.wpi.first.wpilibj.command.Subsystem;

import org.usfirst.frc.team5496.robot.Robot;

import edu.wpi.first.wpilibj.Timer;
/**
 *
 */
public class drive extends Subsystem {
    
    // Put methods for controlling this subsystem
    // here. Call these from Commands.
	    Timer timey= new Timer();
    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        //setDefaultCommand(new MySpecialCommand());
    }
    public  void forward() {
Robot.oi.explTalon.set(0.3);
Robot.oi.exampleTalon.set(0.3);
Robot.oi.explTalon2.set(0.3);
Robot.oi.exampleTalon2.set(0.3);
Timer.delay(0.5);
Robot.oi.explTalon.set(0);
Robot.oi.exampleTalon.set(0);
Robot.oi.explTalon2.set(0);
Robot.oi.exampleTalon2.set(0);
    }
    public  void backward() {
Robot.oi.explTalon.set(-0.3);
Robot.oi.exampleTalon.set(-0.3);
Robot.oi.explTalon2.set(-0.3);
Robot.oi.exampleTalon2.set(-0.3);    
Timer.delay(0.5);
Robot.oi.explTalon.set(0);
Robot.oi.exampleTalon.set(0);
Robot.oi.explTalon2.set(0);
Robot.oi.exampleTalon2.set(0); 
    }
    public void right() {
Robot.oi.explTalon.set(0.3);
Robot.oi.exampleTalon.set(-0.3);
Robot.oi.explTalon2.set(0.3);
Robot.oi.exampleTalon2.set(-0.3); 
Timer.delay(0.5);
Robot.oi.explTalon.set(0);
Robot.oi.exampleTalon.set(0);
Robot.oi.explTalon2.set(0);
Robot.oi.exampleTalon2.set(0);
    }
    public void left(){
Robot.oi.explTalon.set(-0.3);
Robot.oi.exampleTalon.set(0.3);
Robot.oi.explTalon2.set(-0.3);
Robot.oi.exampleTalon2.set(0.3); 
Timer.delay(0.5);
Robot.oi.explTalon.set(0);
Robot.oi.exampleTalon.set(0);
Robot.oi.explTalon2.set(0);
Robot.oi.exampleTalon2.set(0);
    }
    public void shoot(){
	timey.reset();
    	double times = timey.get();
    while(times < 2.5)
    {
    Robot.oi.top.set(0.6);
    }
    while(times<7 && times>2.5);
    {
    	Robot.oi.top.set(-0.3);
    }
    while(times>7)
    	Robot.oi.top.set(0);
    }
    
    public void lift()
    	{
    	Robot.oi.lift.set(true);
    	Robot.oi.lift2.set(true);
        Timer.delay(0.5);
       	Robot.oi.lift.set(!true);
    	Robot.oi.lift2.set(!true);
    	}
        }
    

